<?php 
	function admin_url($url='')
	{
		return base_url('admin/'.$url);
	}
?>