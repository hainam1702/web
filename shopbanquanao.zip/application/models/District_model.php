<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class District_model extends MY_Model {
	var $table = 'district';
}