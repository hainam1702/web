<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Province_model extends MY_Model {
	var $table = 'province';
}