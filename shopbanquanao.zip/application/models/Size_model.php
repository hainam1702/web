<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Size_model extends MY_Model {
	var $table = 'sizes';
}