<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Trang Quản Trị</title>

<link href="<?php echo public_url('admin/'); ?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo public_url('admin/'); ?>css/datepicker3.css" rel="stylesheet">
<link href="<?php echo public_url('admin/'); ?>css/styles.css" rel="stylesheet">
<script src="<?php echo public_url(); ?>js/jquery-3.1.1.js" type="text/javascript"></script>
<script src="<?php echo public_url(); ?>js/jquery.js" type="text/javascript"></script>

<!--Icons-->
<script src="<?php echo public_url('admin/'); ?>js/lumino.glyphs.js"></script>
<script src="<?php echo public_url(); ?>js/ckeditor/ckeditor.js"></script>
<!-- CSS có thể đọc được -->
<link href = 'https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css' rel = 'stylesheet' type = 'text/css'>

<!-- Thư viện jQuery-->
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"> </script>

<!-- JS có thể đọc được -->
<script src = "https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"> </script>