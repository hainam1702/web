<svg id="glyphs-sheet" xmlns="http://www.w3.org/2000/svg" style="display:none;"><defs><symbol id="stroked-bacon-burger" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M41 18H3c-.6 0-1-.4-1-1v-2C2 8.9 6.9 4 13 4h18c6 0 11 4.9 11 11v2c0 .6-.4 1-1 1zM39 37H5c-1.7 0-3-1.3-3-3v-2c0-.6.4-1 1-1h38c.5 0 1 .5 1 1v2c0 1.7-1.3 3-3 3zM1 27h42M1 22c3.5 0 3.5 2 7 2s3.5-2 7-2 3.5 2 7 2 3.5-2 7-2 3.5 2 7 2 3.5-2 7-2" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-paper-coffee-cup" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M31.6 43H12.4L9 9h26z"></path>
    <path d="M35 6H9V2c0-.6.4-1 1-1h24c.6 0 1 .4 1 1v4z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M7 6h30v3H7zM9.8 17h24.4M11.6 35h20.8"></path>
</symbol><symbol id="stroked-round-coffee-mug" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M33 11v16c0 8.8-7.2 16-16 16S1 35.8 1 27V11h32zM37 27h-4V15h4c3.3 0 6 2.7 6 6s-2.7 6-6 6z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-wireless-router" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M33 27v3h-3M39 27v3h-3"></path>
    <path d="M41 34H3c-1.1 0-2-.9-2-2v-6c0-1.1.9-2 2-2h38c1.1 0 2 .9 2 2v6c0 1.1-.9 2-2 2z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M5 34h6v3H5zM33 34h6v3h-6z"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M14 24L7 13.3M30 24l7-10.7"></path>
    <path d="M25.4 15c-.7-1.2-2-2-3.4-2s-2.7.8-3.4 1.9M29.4 10.3C27.6 8.3 24.9 7 22 7c-2.9 0-5.5 1.3-7.4 3.3" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-pen-tip" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M26.7 6L38 17.3l-6.3 13.4L2 42l11.3-29.7zM2 42l19.1-19.1"></path>
    <circle cx="23.2" cy="20.8" r="3" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <path d="M30.5 1.3l12.2 12.2c.5.5.4 1.3-.3 1.6L38 17.3 26.7 6l2.2-4.4c.3-.7 1.1-.8 1.6-.3z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-usb-flash-drive" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M30 43H14c-1.1 0-2-.9-2-2V11h20v30c0 1.1-.9 2-2 2zM15 1h14v10H15z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M20 4v3h-3M25 4v3h-3"></path>
</symbol><symbol id="stroked-toiler-paper" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M9.9 1H33c3.9 0 7 5.8 7 13s-3.1 13-6.9 13H9.9C6.1 27 3 21.2 3 14S6.1 1 9.9 1z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <ellipse cx="33" cy="14" rx="7" ry="13" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></ellipse>
    <ellipse cx="33" cy="14" rx="3" ry="7" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></ellipse>
    <path d="M33.1 27c3.8 0 6.9-5.8 6.9-13v29l-4-2-4 2-4-2-4 2-4-2-3 2V27h16.1z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-pencil" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M13.7 36.9l-7.1-7.1L34.9 1.6c.8-.8 2-.8 2.8 0L42 5.8c.8.8.8 2 0 2.8L13.7 36.9zM1 42.6l5.7-12.7 7 7zM32.8 3.7l7.1 7.1" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-brush" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M18.6 30l-3.9-3.9c-.4-.4-.4-1 0-1.4L38.1 2.5c1.1-1.1 3-1.1 4.1.1 1.1 1.1 1.1 2.9.1 4.1L20.1 30c-.4.4-1.1.4-1.5 0z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <path d="M1 39.9s4.1-3.3 5.4-7.7c1.1-3.7 3.6-6.2 7.1-5.6 3.5.6 5.7 4.4 4.2 7.6-1.6 3.3-8 6.3-16.7 5.7z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-email" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M1 9h42v26H1z"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M17.1 22L1 35h42L26.9 22"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M22 26L1 9h42z"></path>
</symbol><symbol id="stroked-open-letter" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M22 26l21 17H1z"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M1 17v26h42V17"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M26.9 30L43 17 22 1 1 17l16.1 13"></path>
</symbol><symbol id="stroked-laptop-computer-and-mobile" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M33 31H1v3c0 .6.4 1 1 1h31" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M42 37h-8c-.6 0-1-.4-1-1V18c0-.6.4-1 1-1h8c.6 0 1 .4 1 1v18c0 .6-.4 1-1 1zM33 21h10M33 33h10"></path>
    </g>
    <path d="M39 17v-7c0-.6-.4-1-1-1H6c-.6 0-1 .4-1 1v21h28" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-hourglass" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M21.7 22L12 11.7C9.7 9.2 11.5 5 15 5h12.9c3.4 0 5.3 4.1 3 6.6L21.7 22zM21.7 22L12 32.3c-2.3 2.5-.5 6.7 3 6.7h12.9c3.4 0 5.3-4.1 3-6.6L21.7 22zM33.2 5h-24c-.6 0-1-.4-1-1V2c0-.6.4-1 1-1h24c.6 0 1 .4 1 1v2c0 .6-.4 1-1 1zM33.2 43h-24c-.6 0-1-.4-1-1v-2c0-.6.4-1 1-1h24c.6 0 1 .4 1 1v2c0 .6-.4 1-1 1z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <path class="line" fill="none" stroke="#000" stroke-miterlimit="10" d="M14.1 13.5h15M11.6 34.5h4.8c.6 0 1.1-.1 1.6-.3l2.1-.9c1-.5 2.2-.5 3.2 0l2.1.9c.5.2 1.1.3 1.6.3h4.5"></path>
</symbol><symbol id="stroked-internal-hard-drive" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M34.1 7H9.9C8.2 7 6.6 8.1 6.1 9.7L1.6 23.2c-.4 1.2-.6 2.5-.6 3.7V32c0 2.2 1.8 4 4 4h34c2.2 0 4-1.8 4-4v-5.1c0-1.3-.2-2.6-.6-3.8L37.9 9.7C37.4 8.1 35.8 7 34.1 7z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
    <path d="M32.2 13.7c3 3.4-.6 8-10.2 8s-13.2-4.7-10.2-8c1.9-2.1 6.2-3.3 10.2-3.3s8.3 1.2 10.2 3.3z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
    <path d="M24.3 15.6c.7.7-.1 1.7-2.3 1.7s-3-1-2.3-1.7c.4-.4 1.4-.7 2.3-.7s1.9.3 2.3.7z" class="line" fill="none" stroke="#000" stroke-linejoin="round" stroke-miterlimit="10"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M1 26h42"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M14.3 19.6l3.3-1.6"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M6 29v4M9 29v4M12 29v4M15 29v4"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M33 31h6"></path>
</symbol><symbol id="stroked-external-hard-drive" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M34.1 7H9.9C8.2 7 6.6 8.1 6.1 9.7L1.6 23.2c-.4 1.2-.6 2.5-.6 3.7V32c0 2.2 1.8 4 4 4h34c2.2 0 4-1.8 4-4v-5.1c0-1.3-.2-2.6-.6-3.8L37.9 9.7C37.4 8.1 35.8 7 34.1 7zM1 26h42" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M33 31h6M5 31h2"></path>
</symbol><symbol id="stroked-flag" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M9 3v41M37 18.2C25.9 14 20.1 24 9 19.8v-16C20.1 8 25.9-2 37 2.2v16z"></path>
</symbol><symbol id="stroked-desktop-computer-and-mobile" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M39 19V8c0-1.1-.9-2-2-2H3c-1.1 0-2 .9-2 2v22c0 1.1.9 2 2 2h30M27 32l1.3 4.5c.4 1.3-.6 2.5-1.9 2.5h-8.7c-1.3 0-2.3-1.3-1.9-2.5L17 32M1 27h32" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M42 39h-8c-.6 0-1-.4-1-1V20c0-.6.4-1 1-1h8c.6 0 1 .4 1 1v18c0 .6-.4 1-1 1zM33 23h10M33 35h10"></path>
    </g>
</symbol><symbol id="stroked-database" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M42 6c0-2.8-9-5-20-5S2 3.2 2 6v32c0 2.8 9 5 20 5s20-2.2 20-5V6z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
    <path d="M42 6c0 2.8-9 5-20 5S2 8.8 2 6M42 17c0 2.8-9 5-20 5S2 19.8 2 17M42 27c0 2.8-9 5-20 5S2 29.8 2 27" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-hand-cursor" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path d="M33.1 18.3c-.7 0-1.4.3-2 .8-.4-1.3-1.6-2.2-3-2.2-1 0-1.8.4-2.4 1.1-.5-1-1.6-1.7-2.7-1.7-1.3 0-2.6.8-3.1 2V4c0-1.7-1.3-3-3-3s-3 1.3-3 3v19.9c-1.7-2.1-3.8-3.7-6.5-4-3.6-.4-4.2 2.8-2.9 3.5 3.6 1.8 6.9 7 8.5 10.4 2.1 5.2 2.5 9.3 11.3 9.3 4.8 0 7.9-1.6 9.7-5.6 1.5-3.3 2.1-7.1 2.1-14v-1.9c.2-1.8-1.3-3.4-3-3.3z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-arrow-cursor" class="glyph-svg stroked" viewBox="0 0 44 44">
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M6 1l6.5 40.5 7.9-8.9L26.9 43l7.6-4.8-6.4-10.3 11.4-3.3z"></path>
</symbol><symbol id="stroked-chevron-up" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M11.4 27.7L22 17.1l10.6 10.6"></path>
</symbol><symbol id="stroked-chevron-right" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M16.7 11.4L27.3 22 16.7 32.6"></path>
</symbol><symbol id="stroked-chevron-left" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M27.3 32.6L16.7 22l10.6-10.6"></path>
</symbol><symbol id="stroked-chevron-down" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <path class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10" d="M11.4 16.7L22 27.3l10.6-10.6"></path>
</symbol><symbol id="stroked-arrow-up" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M12.1 21.1l9.9-9.9 9.9 9.9M22 34.2v-23"></path>
    </g>
</symbol><symbol id="stroked-arrow-right" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M22.9 12.1l9.9 9.9-9.9 9.9M9.8 22h23"></path>
    </g>
</symbol><symbol id="stroked-arrow-left" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M19.7 31.9L9.8 22l9.9-9.9M32.8 22h-23"></path>
    </g>
</symbol><symbol id="stroked-arrow-down" class="glyph-svg stroked" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="21" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></circle>
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M31.9 24.3L22 34.2l-9.9-9.9M22 11.2v23"></path>
    </g>
</symbol><symbol id="stroked-video" class="glyph-svg stroked" viewBox="0 0 44 36">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M1 33V3c0-1.1.9-2 2-2h38c1.1 0 2 .9 2 2v30c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2zM43 27H1" stroke-linejoin="round"></path>
        <path d="M25.653 15.832l-6.197 4.13c-.665.444-1.555-.032-1.555-.83v-8.264c0-.8.89-1.275 1.557-.832l6.197 4.13c.594.398.594 1.27 0 1.666z"></path>
        <path stroke-linejoin="round" d="M5 31h34"></path>
    </g>
</symbol><symbol id="stroked-female-user" class="glyph-svg stroked" viewBox="0 0 43.477 41.979">
    <path d="M40.476 40.98c1.21 0 2.144-1.068 1.982-2.267l-.005-.037c-.273-2.062-1.634-3.818-3.58-4.555-3.146-1.19-7.507-2.84-8.05-3.04-.4-.14-1.08-1.3-1.32-1.84-.24-.52-1.86-1.58-2.28-1.64l-.06-2.2 7.26-2.68s-1.58-2.94-2.06-4.58c-.48-1.64-.78-4.2-.78-4.44 0-.24-.98-6.12-1.52-7.26-.52-1.14-1.26-2.7-2.5-3.46-1.22-.76-3.06-1.84-5.7-1.98h-.24c-2.64.14-4.48 1.22-5.7 1.98-1.24.76-1.98 2.32-2.5 3.46-.54 1.14-1.52 7.02-1.52 7.26 0 .24-.28 2.9-.74 4.54-.48 1.64-2.1 4.48-2.1 4.48l7.26 2.68-.06 2.2c-.42.06-2.04 1.12-2.28 1.64-.24.54-.92 1.7-1.32 1.84-.53.197-4.715 1.704-7.843 2.83-2.07.744-3.523 2.596-3.8 4.777l-.005.038C.863 39.92 1.795 40.98 3 40.98h37.476z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-film" class="glyph-svg stroked" viewBox="0 0 42 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M39 43H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h36c1.1 0 2 .9 2 2v38c0 1.1-.9 2-2 2zM9 1v42M33 1v42M33 22H9" stroke-linejoin="round"></path>
        <path d="M3 8h2.993V5M3 14h2.993v-3M3 20h2.993v-3M3 26h2.993v-3M3 32h2.993v-3M3 38h2.993v-3M35 8h2.993V5M35 14h2.993v-3M35 20h2.993v-3M35 26h2.993v-3M35 32h2.993v-3M35 38h2.993v-3"></path>
    </g>
</symbol><symbol id="stroked-male-user" class="glyph-svg stroked" viewBox="0 0 44.02 43">
    <path d="M1 38.207c0-1.983 1.168-3.777 2.983-4.575 2.325-1.022 5.505-2.42 7.638-3.366 1.925-.85 2.34-1.363 4.28-2.235 0 0 .2-1.012.13-1.615h1.516s.347.206 0-2.176c0 0-1.85-.5-1.936-4.294 0 0-1.39.476-1.475-1.823-.058-1.56-1.243-2.912.462-4.03l-.867-2.38s-1.733-9.617 3.25-8.206c-2.1-2.56 11.92-5.117 12.83 3 0 0 .65 4.38 0 7.38 0 0 2.05-.24.68 3.765 0 0-.75 2.882-1.907 2.235 0 0 .19 3.646-1.632 4.265 0 0 .13 1.94.13 2.073l1.736.265s-.26 1.588.043 1.764c0 0 2.49 1.29 4.506 2.074 2.378.917 4.86 2.002 6.714 2.84 1.788.81 2.932 2.592 2.93 4.555 0 .847.003 1.63.01 2.007.023 1.224-.873 2.27-2.1 2.27H3.105C1.943 42 1 41.057 1 39.895v-1.688z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-upload" class="glyph-svg stroked" viewBox="0 0 28 41.414">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M17 14.414h8c1.105 0 2 .895 2 2v22c0 1.105-.895 2-2 2H3c-1.105 0-2-.895-2-2v-22c0-1.105.895-2 2-2h8M14 27.414v-26M8.002 7.412L14 1.414l5.998 5.998"></path>
    </g>
</symbol><symbol id="stroked-monitor" class="glyph-svg stroked" viewBox="0 0 44 34">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M1 1h42v28H1z"></path>
        <path stroke-linejoin="round" d="M17 29v4M27 29v4M32 33H12"></path>
        <path d="M38 26h2M35 26h2"></path>
    </g>
</symbol><symbol id="stroked-trash" class="glyph-svg stroked" viewBox="0 0 40 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M4 5l4 38h24l4-38zM0 5h40M12 5V1h16v4"></path>
    </g>
</symbol><symbol id="stroked-line-graph" class="glyph-svg stroked" viewBox="0 0 44 33">
    <path class="line" fill="none" stroke="currentColor" stroke-width="2" stroke-miterlimit="10" d="M1 0v32h43.004"></path>
    <path class="line" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M43 32H1v-5l14-14 14 8L43 4z"></path>
</symbol><symbol id="stroked-tag" class="glyph-svg stroked" viewBox="0 0 42.143 42.15">
    <g clip-rule="evenodd" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M40.555 25.002l-15.56 15.56c-.78.78-2.04.785-2.813.012L1.576 19.968c-.373-.374-.58-.882-.576-1.413l.143-15.557C1.153 1.9 2.05 1.01 3.148 1.01L18.558 1c.525 0 1.027.207 1.397.576L40.568 22.19c.772.772.767 2.032-.013 2.812z"></path>
        <circle cx="9.44" cy="9.447" r="3"></circle>
    </g>
</symbol><symbol id="stroked-tablet-1" class="glyph-svg stroked" viewBox="0 0 32 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M29 43H3c-1.105 0-2-.895-2-2V3c0-1.105.895-2 2-2h26c1.105 0 2 .895 2 2v38c0 1.105-.895 2-2 2zM1 37h30M1 7h30M15 40h2"></path>
    </g>
</symbol><symbol id="stroked-table" class="glyph-svg stroked" viewBox="0 0 44 34">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M1 1h42v32H1z"></path>
        <path stroke-linejoin="round" d="M43 9H1M43 17H1M43 25H1M4 5h8M4 13h8M4 21h8M4 29h8M18 5h8M32 5h8M15 1v32M29 1v32"></path>
    </g>
</symbol><symbol id="stroked-star" class="glyph-svg stroked" viewBox="0 0 41.681 41.585">
    <path d="M22.652 2.15l4.53 9.666c.282.604.848 1.027 1.507 1.128l10.29 1.575c1.61.244 2.265 2.205 1.13 3.37l-7.576 7.78c-.442.453-.643 1.09-.54 1.716l1.77 10.87c.267 1.65-1.483 2.88-2.944 2.072l-9.012-4.99c-.603-.335-1.335-.335-1.938 0l-9.013 4.99c-1.46.808-3.21-.424-2.943-2.072l1.77-10.87c.102-.627-.1-1.264-.54-1.718L1.567 17.89c-1.135-1.165-.478-3.126 1.13-3.373L12.99 12.94c.66-.1 1.223-.523 1.506-1.127l4.53-9.665c.722-1.534 2.905-1.534 3.625 0z" clip-rule="evenodd" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-sound-on" class="glyph-svg stroked" viewBox="0 0 37 31.135">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M9 23.002H2c-.552 0-1-.448-1-1v-12c0-.552.448-1 1-1h7v14zM19.445 29.965L9 23.002v-14l10.4-7.8c.66-.494 1.6-.024 1.6.8v27.13c0 .8-.89 1.276-1.555.833zM27 16.002h10M25.464 22.466l7.072 7.07M25.464 9.537l7.072-7.07"></path>
    </g>
</symbol><symbol id="stroked-printer" class="glyph-svg stroked" viewBox="0 0 44 43">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M9 34H3c-1.105 0-2-.895-2-2V16c0-1.105.895-2 2-2h38c1.105 0 2 .895 2 2v16c0 1.105-.895 2-2 2h-6" clip-rule="evenodd"></path>
        <path clip-rule="evenodd" d="M9 29h26v13H9zM9 14V1h26v13"></path>
        <path d="M1 22h42"></path>
    </g>
</symbol><symbol id="stroked-plus-sign" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <circle cx="22" cy="22" r="21"></circle>
        <path d="M11 22h22M22 10v23"></path>
    </g>
</symbol><symbol id="stroked-landscape" class="glyph-svg stroked" viewBox="0 0 44 34">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M41 33H3c-1.105 0-2-.895-2-2V3c0-1.105.895-2 2-2h38c1.105 0 2 .895 2 2v28c0 1.105-.895 2-2 2z"></path>
        <path stroke-linejoin="round" d="M1 22.417l13-13 12.708 15.708 9.25-6.25L43.168 28"></path>
        <circle cx="32.167" cy="10" r="3"></circle>
    </g>
</symbol><symbol id="stroked-paperclip" class="glyph-svg stroked" viewBox="0 0 39.918 44.292">
    <path d="M39 19.872L18.588 40.285c-4.01 4.01-10.57 4.01-14.58 0s-4.01-10.57 0-14.58l22.6-22.6c2.807-2.807 7.4-2.807 10.206 0 2.807 2.807 2.807 7.4 0 10.206L16.4 33.726c-1.604 1.604-4.228 1.604-5.832 0s-1.604-4.228 0-5.832L28.794 9.666" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-notepad" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M41 43H3c-1.105 0-2-.895-2-2V6c0-1.105.895-2 2-2h38c1.105 0 2 .895 2 2v35c0 1.105-.895 2-2 2zM1 15h42M9 0v8M35 0v8M5 21h34M5 26h34M5 31h34M5 36h34"></path>
    </g>
</symbol><symbol id="stroked-music" class="glyph-svg stroked" viewBox="0 0 37 43.623">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M36 10.623l-23 4V6.305c0-.972.7-1.804 1.657-1.97l19-3.304C34.88.82 36 1.76 36 3v7.623zM8 42.623H6c-2.76 0-5-2.24-5-5s2.24-5 5-5h7v5c0 2.76-2.24 5-5 5zM12.995 14.626v22.85M31 38.623h-2c-2.76 0-5-2.24-5-5s2.24-5 5-5h7v5c0 2.76-2.24 5-5 5zM35.995 10.626v22.85"></path>
    </g>
</symbol><symbol id="stroked-mobile-device" class="glyph-svg stroked" viewBox="0 0 24 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M21 43H3c-1.105 0-2-.895-2-2V3c0-1.105.895-2 2-2h18c1.105 0 2 .895 2 2v38c0 1.105-.895 2-2 2zM1 37h22M1 7h22M10 4h4M11 40h2"></path>
    </g>
</symbol><symbol id="stroked-two-messages" class="glyph-svg stroked" viewBox="0 0 44 39.035">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10">
        <path d="M40.962 18.79c.01-.217.038-.43.038-.647C41 8.675 32.046 1 21 1S1 8.675 1 18.143c0 4.466 2.01 8.52 5.275 11.572-.612 2.002-1.97 5.11-4.83 7.05 0 0 6.747-.76 11.067-3.117 2.58 1.04 5.45 1.638 8.49 1.638.253 0 .5-.025.752-.033"></path>
        <path d="M29 13c7.732 0 14 5.373 14 12 0 3.127-1.407 5.965-3.692 8.1.428 1.4 1.38 3.577 3.382 4.935 0 0-4.724-.533-7.748-2.182C33.136 36.58 31.128 37 29 37c-7.732 0-14-5.373-14-12s6.268-12 14-12z"></path>
        <circle cx="21" cy="25" r="2"></circle>
        <circle cx="29" cy="25" r="2"></circle>
        <circle cx="37" cy="25" r="2"></circle>
    </g>
</symbol><symbol id="stroked-empty-message" class="glyph-svg stroked" viewBox="0 0 44 39.553">
    <path d="M22 1C10.402 1 1 9.06 1 19c0 4.69 2.11 8.947 5.538 12.15-.643 2.102-2.07 5.365-5.073 7.403 0 0 7.086-.8 11.62-3.273C15.795 36.372 18.81 37 22 37c11.598 0 21-8.06 21-18S33.598 1 22 1z" class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-map" class="glyph-svg stroked" viewBox="0 0 44 38.838">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M43 32.42l-14 5-14-5-14 5v-31l14-5 14 5 14-5zM15 1.42v31M29 6.42v31"></path>
    </g>
</symbol><symbol id="stroked-lock" class="glyph-svg stroked" viewBox="0 0 34 40">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M1 14v24c0 .552.448 1 1 1h30c.552 0 1-.448 1-1V14c0-.552-.448-1-1-1H2c-.552 0-1 .448-1 1zM8 13V6c0-2.76 2.24-5 5-5h8c2.76 0 5 2.24 5 5v7"></path>
        <circle cx="17" cy="24" r="3"></circle>
        <path d="M17 27v5"></path>
    </g>
</symbol><symbol id="stroked-location-pin" class="glyph-svg stroked" viewBox="0 0 30 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10">
        <path d="M29 15c0 11.58-14 28-14 28S1 27.024 1 15C1 7.268 7.268 1 15 1s14 6.268 14 14z"></path>
        <circle cx="15" cy="15" r="6"></circle>
    </g>
</symbol><symbol id="stroked-chain" class="glyph-svg stroked" viewBox="0 0 39.689 39.689">
    <g clip-rule="evenodd" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M18.43 21.26l2.828 2.827c1.556 1.556 4.1 1.556 5.657 0L37.522 13.48c1.556-1.556 1.556-4.1 0-5.657l-5.657-5.657c-1.556-1.556-4.1-1.556-5.657 0l-9.192 9.192"></path>
        <path d="M21.26 18.43l-2.83-2.828c-1.555-1.556-4.1-1.556-5.656 0L2.167 26.208c-1.556 1.556-1.556 4.1 0 5.657l5.657 5.657c1.556 1.556 4.1 1.556 5.657 0l9.194-9.192"></path>
    </g>
</symbol><symbol id="stroked-key" class="glyph-svg stroked" viewBox="0 0 41.284 44.113">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <circle cx="28.284" cy="13" r="12"></circle>
        <path d="M19.8 21.485L.706 40.577M2.828 38.456l7.07-7.07 4.244 4.242-7.07 7.07z"></path>
    </g>
</symbol><symbol id="stroked-heart" class="glyph-svg stroked" viewBox="0 0 44 36.504">
    <path d="M42.087 17.245C40.037 22.188 27.21 32.09 23.2 35.103c-.712.535-1.68.535-2.393 0-4.01-3.01-16.843-12.915-18.894-17.858C-.543 11.323 2.126 4.47 7.876 1.94 13.126-.37 19.126 1.723 22 6.61c2.874-4.887 8.874-6.98 14.124-4.67 5.75 2.53 8.42 9.383 5.963 15.305z" clip-rule="evenodd" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10"></path>
</symbol><symbol id="stroked-home" class="glyph-svg stroked" viewBox="0 0 43.447 43.448">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M42.723 23.448l-21-22-21 22"></path>
        <path d="M5.723 18.448v24h11v-16h10v16h11v-24"></path>
    </g>
</symbol><symbol id="stroked-gear" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M41.803 18.1l-3.013-1.003c-.36-1.23-.84-2.408-1.447-3.51l1.416-2.833c.335-.674.203-1.487-.33-2.02l-3.166-3.166c-.533-.533-1.346-.665-2.02-.328l-2.832 1.416c-1.102-.606-2.28-1.088-3.51-1.447l-1.005-3.015C25.66 1.482 24.992 1 24.237 1h-4.475c-.753 0-1.422.482-1.66 1.197L17.098 5.21c-1.23.36-2.408.84-3.51 1.447L10.753 5.24c-.674-.337-1.487-.205-2.02.328L5.568 8.734c-.533.533-.665 1.346-.328 2.02l1.416 2.832c-.606 1.102-1.088 2.28-1.447 3.51L2.194 18.1C1.482 18.34 1 19.01 1 19.76v4.478c0 .753.482 1.422 1.197 1.66l3.013 1.004c.36 1.23.84 2.408 1.447 3.51L5.24 33.247c-.337.674-.205 1.487.328 2.02l3.166 3.166c.533.533 1.346.665 2.02.328l2.832-1.415c1.102.606 2.28 1.088 3.51 1.447l1.005 3.014c.24.714.91 1.196 1.66 1.196h4.48c.752 0 1.42-.482 1.66-1.197l1.003-3.013c1.23-.36 2.408-.84 3.51-1.447l2.833 1.416c.674.337 1.487.205 2.02-.33l3.166-3.164c.534-.533.666-1.346.33-2.02l-1.417-2.832c.606-1.102 1.088-2.28 1.447-3.51l3.013-1.005c.715-.238 1.197-.907 1.197-1.66v-4.477c0-.754-.482-1.423-1.197-1.66z"></path>
        <circle cx="22" cy="22" r="11"></circle>
    </g>
</symbol><symbol id="stroked-folder" class="glyph-svg stroked" viewBox="0 0 44 34">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M23 3c0-1.105-.895-2-2-2H3c-1.105 0-2 .895-2 2v28c0 1.105.895 2 2 2h38c1.105 0 2-.895 2-2V7c0-1.105-.895-2-2-2H25c-1.105 0-2-.895-2-2zM1 9h41.992"></path>
    </g>
</symbol><symbol id="stroked-open-folder" class="glyph-svg stroked" viewBox="0 0 43.62 34">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M22.81 3c0-1.105-.895-2-2-2h-16c-1.105 0-2 .895-2 2v8h38V7c0-1.105-.895-2-2-2h-14c-1.104 0-2-.895-2-2zM1.008 13.18l1.636 18c.094 1.03.958 1.82 1.993 1.82h34.347c1.034 0 1.898-.79 1.992-1.82l1.636-18c.106-1.17-.816-2.18-1.992-2.18H3c-1.176 0-2.098 1.01-1.992 2.18z"></path>
    </g>
</symbol><symbol id="stroked-eye" class="glyph-svg stroked" viewBox="0 0 44.409 30">
    <g clip-rule="evenodd" class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M22.204 1c-11.603 0-21 14-21 14s9.397 14 21 14 21-14 21-14-9.397-14-21-14z"></path>
        <circle cx="22.204" cy="15" r="8"></circle>
        <circle cx="22.204" cy="15" r="2"></circle>
    </g>
</symbol><symbol id="stroked-download" class="glyph-svg stroked" viewBox="0 0 28 40">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M17 13h8c1.105 0 2 .895 2 2v22c0 1.105-.895 2-2 2H3c-1.105 0-2-.895-2-2V15c0-1.105.895-2 2-2h8M14 0v26"></path>
        <path d="M19.998 20.002L14 26l-5.998-5.998"></path>
    </g>
</symbol><symbol id="stroked-blank-document" class="glyph-svg stroked" viewBox="0 0 34 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M31 43H3c-1.105 0-2-.895-2-2V3c0-1.105.895-2 2-2h17.172c.53 0 1.04.21 1.414.586l10.828 10.828c.375.375.586.884.586 1.414V41c0 1.105-.895 2-2 2z"></path>
        <path d="M21 1v9.952c0 1.105.895 2 2 2h10"></path>
    </g>
</symbol><symbol id="stroked-desktop" class="glyph-svg stroked" viewBox="0 0 44 37">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M41 29H3c-1.105 0-2-.895-2-2V3c0-1.105.895-2 2-2h38c1.105 0 2 .895 2 2v24c0 1.105-.895 2-2 2zM27 29l1.272 4.45c.365 1.278-.595 2.55-1.923 2.55h-8.7c-1.33 0-2.288-1.272-1.923-2.55L17 29M1 24h42"></path>
    </g>
</symbol><symbol id="stroked-dashboard-dial" class="glyph-svg stroked" viewBox="0 0 44 32">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M22 10v11"></path>
        <circle cx="22" cy="24" r="3"></circle>
        <path d="M22 4v3M13 6.412l1.5 2.598M6.412 13l2.598 1.5M4 22h3M40 22h-3M37.588 13l-2.598 1.5M31 6.412L29.5 9.01M41.514 29.714c1.134-2.848 1.677-5.993 1.426-9.302C42.143 9.907 33.437 1.464 22.91 1.02 10.9.51 1 10.1 1 22c0 2.73.536 5.327 1.487 7.716C2.794 30.486 3.53 31 4.36 31h35.28c.83 0 1.566-.515 1.874-1.286z"></path>
    </g>
</symbol><symbol id="stroked-clock" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M31 22h-9V5"></path>
        <circle cx="22" cy="22" r="21"></circle>
        <path d="M22 36v3M39 22h-3M8 22H5"></path>
    </g>
</symbol><symbol id="stroked-clipboard-with-paper" class="glyph-svg stroked" viewBox="0 0 32 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M23 5h6c1.105 0 2 .895 2 2v34c0 1.105-.895 2-2 2H3c-1.105 0-2-.895-2-2V7c0-1.105.895-2 2-2h6"></path>
        <path d="M20 3c0-1.105-.895-2-2-2h-4c-1.105 0-2 .895-2 2h-2c-.552 0-1 .448-1 1v2c0 .552.448 1 1 1h12c.552 0 1-.448 1-1V4c0-.552-.448-1-1-1h-2zM12 16h16M5 14h4v4H5zM12 24h16M5 22h4v4H5zM12 32h16M5 30h4v4H5z"></path>
    </g>
</symbol><symbol id="stroked-checkmark" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <circle cx="22" cy="22" r="21"></circle>
        <path d="M34.58 14.11L17.61 31.08l-9.19-9.19"></path>
    </g>
</symbol><symbol id="stroked-cancel" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <circle cx="22" cy="22" r="21"></circle>
        <path d="M13.868 14.075l15.557 15.557M30.132 13.368L13.868 29.632"></path>
    </g>
</symbol><symbol id="stroked-camcorder" class="glyph-svg stroked" viewBox="0 0 44 24">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M31 23H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h28c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2zM41.375 21.7L33 15V9l8.375-6.7C42.03 1.776 43 2.242 43 3.08v17.84c0 .838-.97 1.304-1.625.78z"></path>
    </g>
</symbol><symbol id="stroked-camera" class="glyph-svg stroked" viewBox="0 0 44 33">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M30.497 4.743l-.994-2.486C29.2 1.497 28.463 1 27.646 1H16.354c-.818 0-1.553.498-1.857 1.257l-.994 2.486C13.2 5.503 12.463 6 11.646 6H3c-1.105 0-2 .895-2 2v22c0 1.105.895 2 2 2h38c1.105 0 2-.895 2-2V8c0-1.105-.895-2-2-2h-8.646c-.818 0-1.553-.498-1.857-1.257z"></path>
        <circle cx="22" cy="19" r="9"></circle>
        <path d="M32 11h4"></path>
    </g>
</symbol><symbol id="stroked-calendar" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M41 43H3c-1.105 0-2-.895-2-2V6c0-1.105.895-2 2-2h38c1.105 0 2 .895 2 2v35c0 1.105-.895 2-2 2zM1 15h42M9 0v8M35 0v8"></path>
        <path d="M5 23h4v-4M12 23h4v-4M19 23h4v-4M26 23h4v-4M33 23h4v-4M5 30h4v-4M12 30h4v-4M19 30h4v-4M26 30h4v-4M33 30h4v-4M5 37h4v-4M12 37h4v-4M19 37h4v-4M26 37h4v-4M33 37h4v-4"></path>
    </g>
</symbol><symbol id="stroked-calendar-blank" class="glyph-svg stroked" viewBox="0 0 44 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M41 43H3c-1.105 0-2-.895-2-2V6c0-1.105.895-2 2-2h38c1.105 0 2 .895 2 2v35c0 1.105-.895 2-2 2zM1 15h42M9 0v8M35 0v8"></path>
    </g>
</symbol><symbol id="stroked-basket" class="glyph-svg stroked" viewBox="0 0 44 43">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M20 16V1h4v15M36.18 42H7.82c-.477 0-.887-.336-.98-.804L3 22h38l-3.84 19.196c-.093.468-.503.804-.98.804zM42 22H2c-.552 0-1-.448-1-1v-4c0-.552.448-1 1-1h40c.552 0 1 .448 1 1v4c0 .552-.448 1-1 1z"></path>
    </g>
</symbol><symbol id="stroked-bag" class="glyph-svg stroked" viewBox="0 0 39.797 44">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M11.9 12V9c0-4.418 3.58-8 8-8 4.417 0 8 3.582 8 8v3M34.083 43H5.713c-1.03 0-1.89-.782-1.99-1.807L1.005 13.096C.948 12.51 1.41 12 2 12h35.797c.59 0 1.052.51.995 1.096l-2.72 28.096c-.098 1.026-.96 1.808-1.99 1.808z"></path>
    </g>
</symbol><symbol id="stroked-app-window" class="glyph-svg stroked" viewBox="0 0 44 38">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10">
        <path d="M1 35V3c0-1.1.9-2 2-2h38c1.1 0 2 .9 2 2v32c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2zM43 9H1M4 5h2M7 5h2M10 5h2"></path>
    </g>
</symbol><symbol id="stroked-app-window-with-content" class="glyph-svg stroked" viewBox="0 0 44 38">
    <g class="line" fill="none" stroke="#000" stroke-width="2" stroke-miterlimit="10">
        <path d="M1 35V3c0-1.1.9-2 2-2h38c1.1 0 2 .9 2 2v32c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2zM43 9H1M4 5h2M7 5h2M10 5h2M20 24h20M20 28h20M20 32h20" stroke-linejoin="round"></path>
        <path d="M5 13h34.008v7H5zM5 24h12v8H5z"></path>
    </g>
</symbol></defs></svg>