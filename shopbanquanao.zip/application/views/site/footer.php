

<div class="row" style="display: block;margin-bottom: 100px"></div>
<!--<div class="row" id="footer" style="margin-top: 10px;padding-bottom: 60px;padding-top: 40px">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class=" col-md-2" style="width: auto">
            <a href="https://ute.udn.vn/default.aspx" target="_blank"><img  style="max-width: 100px" src="<?php echo base_url(); ?>upload/logo-truong-250.png" alt="" class="img-responsive"></a>
        </div>
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8" style="padding-top: 10px">
            <address>
                <strong>    SHOP Bán Quần Áo</strong><br>
                <span class="glyphicon glyphicon-home" aria-hidden="true"></span> Địa chỉ: UTE - Cao Thắng - Đà Nẵng<br>
                <span class="glyphicon glyphicon-phone" aria-hidden="true"></span> Điện thoại: 0123456789<br>
                Copyright ©2017 - Design by ---
            </address>
        </div>

        <div class="clearfix"></div>
    </div>
</div>-->

<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="footer__about">
                    <div class="footer__logo">
                        <a href="<?php echo base_url(); ?>" style="pointer-events: none;padding: 10px;background-color: white"><img src="<?php echo base_url(); ?>upload/logo.png" alt="" class="img-responsive"></a>
                    </div>
                    <p>Khách hàng là trọng tâm của mô hình kinh doanh độc đáo của chúng tôi, bao gồm cả thiết kế.</p>
                    <a href="#"><img src='<?php echo base_url('upload/payment.png'); ?>'></a>
                </div>
            </div>
            <div class="col-lg-2 offset-lg-1 col-md-3 col-sm-6">
                <div class="footer__widget">
                    <h6>LPT Shopping</h6>
                    <ul>
                        <li><a href="<?php echo base_url('moi'); ?>">Mới</a></li>
                        <li><a href="<?php echo base_url('ban-chay'); ?>">Bán Chạy</a></li>
                        <li><a href="<?php echo base_url('khuyen-mai'); ?>">Khuyến Mại</a></li>
                        
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="footer__widget">
                    <h6>LPT SHOP</h6>
                    <ul>
                        <li><a href="#">Liên hệ với chúng tôi</a></li>
                        <li><a href="#">Phương thức thanh toán</a></li>
                        <li><a href="#">Giao Hàng</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 offset-lg-1 col-md-6 col-sm-6">
                <div class="footer__widget">
                    <h6>ĐỊA CHỈ EMAIL</h6>
                    <div class="footer__newslatter">
                        <p>Hãy là người đầu tiên biết về hàng mới xuất hiện, xem sách, bán hàng &amp; quảng cáo!</p>
                        <form action="#">
                            <input type="text" placeholder="Nhập Email" style="color: #ffffff">
                            <button type="submit"><i class="fa fa-envelope "></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="footer__copyright__text">
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    <p>Copyright ©
                        <script>
                            document.write(new Date().getFullYear());
                        </script>
                        All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" >Nhóm 18</a>
                    </p>
                    <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                </div>
            </div>
        </div>
    </div>
</footer>