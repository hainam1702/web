jQzoom Evolution Library - Javascript Image magnifier
==================================================
